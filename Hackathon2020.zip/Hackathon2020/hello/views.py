from django.http import HttpResponse,JsonResponse
from django.shortcuts import render
import logging

def test(request):
    return render(request, "hello/test.html")

def index(request):
    return render(request, "hello/index.html")

def formsubmit(request):
    print("success1")
    postBody = request.body
    print(postBody)
    print("success2")
    return HttpResponse("ok")
